import React from "react";

// reactstrap components
import {
  Button,
  NavItem,
  NavLink,
  Nav,
  TabContent,
  TabPane,
  Container,
  Row,
  Col,
  UncontrolledTooltip
} from "reactstrap";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import ProfilePageHeader from "components/Headers/ProfilePageHeader.js";
import DefaultFooter from "components/Footers/DefaultFooter.js";
import Postform from "components/Forms/Postform.js";

function ProfilePage() {
  const [pills, setPills] = React.useState("2");
  React.useEffect(() => {
    document.body.classList.add("profile-page");
    document.body.classList.add("sidebar-collapse");
    document.documentElement.classList.remove("nav-open");
    return function cleanup() {
      document.body.classList.remove("profile-page");
      document.body.classList.remove("sidebar-collapse");
    };
  });
  return (
    <>
      <IndexNavbar />
      <div className="wrapper">
        <ProfilePageHeader />
        <div className="section">
          <Container>
      
            <Row>
              <Col className="ml-auto mr-auto" md="6">
              <h4 className="title text-center">Plant Leaf Analysis</h4>
                <Postform/>
              </Col>
              <Col className="ml-auto mr-auto" md="6">
              <h3 className="title">Revolutionize your farming now</h3>
              <h5 className="description">
              With the power of machine learning, we integrate the latest technologies into agriculture and make them accessible to everyone at all times. 
              This is our contribution to securing global food production.  Specializing in agricultural crops that feed the world,
              Agro App empowers farmers to make a living by providing comprehensive support on all issues that are important to farmers
              </h5>
              </Col>
            </Row>
          </Container>
        </div>
        <DefaultFooter />
      </div>
    </>
  );
}

export default ProfilePage;
