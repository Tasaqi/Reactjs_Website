import React, {Component} from 'react'
import axios from 'axios'

class Postform extends Component{
    constructor(props)
    {
        super(props)
        this.state=
        {
            image:null,
            Plantname:'tomatoes',
            result: [],
            categories:['Tomato_Bacterial_spot', 'Tomato_Early_blight', 'Tomato_healthy',  'Tomato_Late_blight', 'Tomato_Leaf_Mold', 'Tomato_Septoria_leaf_spot', 'Tomato_Spider_mites_Two_spotted_spider_mite',  'Tomato__Target_Spot',  'Tomato__Tomato_mosaic_virus','Tomato__Tomato_YellowLeaf__Curl_Virus']

        }
    }
    fileChangedHandler = event => {
        this.setState({ image: event.target.files[0] })
    }
    handleChange=event=> {
        this.setState({Plantname: event.target.value});
    }
    uploadHandler = () => {
        const formData = new FormData()
        formData.append(
            "image",
          this.state.image
        )
        formData.append(
            "plantname",
          this.state.Plantname,
        )
        axios.post('http://localhost:8000/tomatoes/image/', formData)
        .then(response => { 
            this.setState({result:response.data.Result})
            console.log(this.state.result)
        })
        .catch(error => {
            console.log(error.response)
        });
        console.log(this.state.Plantname)
      }
    render()
    {
        const list=[...this.state.result];
        const cat=[...this.state.categories];
        return(
            
            <div>
               <div>
                    <label>
                        Pick your favorite flavor: 
                        <select value={this.state.value} onChange={this.handleChange}>
                            <option value="tomatoes">Tomatoes</option>
                            <option value="lime">Lime</option>
                            <option value="coconut">Coconut</option>
                            <option value="mango">Mango</option>
                        </select>
                    </label><br/>
                    <input type="file" onChange={this.fileChangedHandler}/><br/><br/>
                    <button onClick={this.uploadHandler}>Send Data to Machine Learning Model!</button>
               </div>
               <div>
                   <h4>Results</h4>
                   <br/>
                <ul>
                    {list.map(item => {
                    return <li key={item}>{cat[list.indexOf(item)]}----> {item}</li>;
                    })}
                </ul>
               </div>
            </div>

            
        );
    }
}

export default Postform
